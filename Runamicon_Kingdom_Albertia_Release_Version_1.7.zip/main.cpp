#include "includes.h"
#include "Game.h"

int main() {
  Game mainGame;
  mainGame.Start();
}